import time
# import googletrans
from translate import Translator
from pyrogram import Client, filters
from shadowhawk.utils.Logging import log_errors, public_log_errors
from shadowhawk import config

__help_section__ = "Translate"

# PROBLEM_CODES = set(i for i in googletrans.LANGUAGES if "-" in i)
ZWS = "\u200B"

@Client.on_message(
	~filters.sticker
	& ~filters.via_bot
	& ~filters.edited
	& filters.me
	& filters.command(["tr", "translate"], prefixes=config["config"]["prefixes"])
)
@log_errors
@public_log_errors
async def translate(client, message):
	"""{prefix}translate <i>(as reply to text)</i> <i>[src]:[dest]</i> - Translates text and stuff
Aliases: {prefix}tr
	"""

	if not message.reply_to_message or (not message.reply_to_message.text and not message.reply_to_message.caption):
		await message.reply_text("Reply required")
		return

	text = message.reply_to_message.text or message.reply_to_message.caption

	src_lang = "autodetect"
	dest_lang = "en"
	lang = " ".join(message.command[1:])

	# for i in PROBLEM_CODES:
	# 	if lang.startswith(i):
	# 		lang = lang[len(i) + 1 :]
	# 		if lang:
	# 			src_lang = i
	# 			dest_lang = lang
	# 		else:
	# 			dest_lang = i
	# 		break
	# else:
	lang = lang.split(":", 1)
	if len(lang) == 1 or not lang[-1]:
		dest_lang = lang.pop(0) or dest_lang
	else:
		dest_lang = lang.pop(0)

	def _translate():
		while True:
			try:
				print(f"to: {dest_lang}, from: {src_lang}")
				return Translator(to_lang=dest_lang, from_lang=src_lang).translate(text)
			except AttributeError:
				time.sleep(0.5)

	result = await client.loop.run_in_executor(None, _translate)
	if result == text:
		await message.reply_text("They're the same")
	else:
		reply = None
		for ping in range(0, 2):
			ping = bool(ping)

			text = f"Translated from {src_lang} to {dest_lang}:\n{result[:4000] if ping else result.replace('@', '@' + ZWS)[:4000]}"

			if ping:
				if reply.text != text:
					reply.edit_text(text, parse_mode=None, display_web_page_preview=True)
			else:
				reply = await message.reply(text, parse_mode=None, disable_web_page_preview=True)


__signature__ = "SHSIG-IPr7Al+fCiXyJCnA5B0SG1JrjEY158vP40KxpEtvaSEZAAAAIFQN0rLXuisJMfhf9gpSeWo8gW06/xBkV/KH7JZb6pXjAAAA"